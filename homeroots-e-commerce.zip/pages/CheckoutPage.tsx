
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

const CheckoutPage: React.FC = () => {
  const { cartItems, clearCart } = useCart();
  const navigate = useNavigate();

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  const shipping = 50;
  const total = subtotal + shipping;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would process payment here
    console.log("Placing order...");
    clearCart();
    navigate('/confirmation');
  };
  
  if (cartItems.length === 0) {
      navigate('/cart');
      return null;
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-serif font-bold text-brand-primary mb-8 text-center">Checkout</h1>
      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-serif font-bold text-brand-primary mb-6">Shipping Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="First Name" className="w-full px-4 py-2 border border-stone-300 rounded-md" required />
            <input type="text" placeholder="Last Name" className="w-full px-4 py-2 border border-stone-300 rounded-md" required />
            <input type="email" placeholder="Email Address" className="md:col-span-2 w-full px-4 py-2 border border-stone-300 rounded-md" required />
            <textarea placeholder="Shipping Address" className="md:col-span-2 w-full px-4 py-2 border border-stone-300 rounded-md" rows={3} required />
            <input type="text" placeholder="City" className="w-full px-4 py-2 border border-stone-300 rounded-md" required />
            <input type="text" placeholder="Pincode" className="w-full px-4 py-2 border border-stone-300 rounded-md" required />
          </div>
           <h2 className="text-2xl font-serif font-bold text-brand-primary mt-8 mb-6">Payment Method</h2>
            <div className="bg-stone-50 p-4 rounded-md border border-stone-200">
                <p className="font-semibold">Razorpay (Mock)</p>
                <p className="text-sm text-stone-500">You will be redirected to Razorpay to complete your payment.</p>
            </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md h-fit">
          <h2 className="text-2xl font-serif font-bold text-brand-primary mb-4">Your Order</h2>
          <div className="space-y-2 border-b border-stone-200 pb-4">
            {cartItems.map(item => (
                <div key={item.id} className="flex justify-between text-sm">
                    <p>{item.name} x {item.quantity}</p>
                    <p>₹{(item.price * item.quantity).toFixed(2)}</p>
                </div>
            ))}
          </div>
          <div className="space-y-2 mt-4">
            <div className="flex justify-between">
              <p>Subtotal</p>
              <p>₹{subtotal.toFixed(2)}</p>
            </div>
            <div className="flex justify-between">
              <p>Shipping</p>
              <p>₹{shipping.toFixed(2)}</p>
            </div>
            <div className="flex justify-between font-bold text-lg border-t border-stone-200 pt-2 mt-2">
              <p>Total</p>
              <p>₹{total.toFixed(2)}</p>
            </div>
          </div>
          <button type="submit" className="w-full mt-6 bg-brand-primary text-white font-bold py-3 rounded-md hover:bg-brand-dark transition duration-300">
            Place Order
          </button>
        </div>
      </form>
    </div>
  );
};

export default CheckoutPage;
