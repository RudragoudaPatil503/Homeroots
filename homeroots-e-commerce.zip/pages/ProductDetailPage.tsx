
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products } from '../data';
import StarRating from '../components/StarRating';
import { useCart } from '../hooks/useCart';
import NotFoundPage from './NotFoundPage';

const ProductDetailPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const [isAdded, setIsAdded] = useState(false);

  const product = products.find(p => p.id === productId);

  if (!product) {
    return <NotFoundPage />;
  }

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <img src={product.image} alt={product.name} className="w-full h-auto object-cover rounded-lg shadow-lg" />
        </div>
        <div>
          <h1 className="text-4xl font-serif font-bold text-brand-primary mb-2">{product.name}</h1>
          <div className="flex items-center gap-4 mb-4">
            <StarRating rating={product.rating} />
            <span className="text-stone-500">{product.reviews.length} reviews</span>
          </div>
          <p className="text-3xl font-bold text-brand-dark mb-4">₹{product.price.toFixed(2)}</p>
          <p className="text-stone-600 mb-6">{product.longDescription}</p>
          
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center border border-stone-300 rounded-md">
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-4 py-2 text-lg font-bold">-</button>
              <span className="px-4 py-2 text-lg">{quantity}</span>
              <button onClick={() => setQuantity(q => q + 1)} className="px-4 py-2 text-lg font-bold">+</button>
            </div>
            <button 
              onClick={handleAddToCart}
              className={`w-full py-3 px-6 rounded-md font-bold text-white transition-colors duration-300 ${
                isAdded ? 'bg-green-600' : 'bg-brand-primary hover:bg-brand-dark'
              }`}
            >
              {isAdded ? 'Added to Cart!' : 'Add to Cart'}
            </button>
          </div>
          
          <p className="text-sm text-stone-500">Category: <Link to={`/products?category=${product.category}`} className="text-brand-primary hover:underline">{product.category}</Link></p>
        </div>
      </div>

      <div className="mt-16 pt-8 border-t border-stone-200">
          <h2 className="text-2xl font-serif font-bold text-brand-primary mb-6">Customer Reviews</h2>
          <div className="space-y-6">
              {product.reviews.length > 0 ? (
                product.reviews.map(review => (
                  <div key={review.id} className="bg-white p-4 rounded-lg shadow-sm">
                    <div className="flex items-center mb-2">
                        <StarRating rating={review.rating} />
                        <p className="ml-4 font-bold text-brand-dark">{review.author}</p>
                    </div>
                    <p className="text-stone-600">{review.comment}</p>
                  </div>
                ))
              ) : (
                <p className="text-stone-500">No reviews yet for this product.</p>
              )}
          </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
