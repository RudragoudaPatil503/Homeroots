
import React from 'react';
import { Link } from 'react-router-dom';

const ConfirmationPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <div className="bg-white p-8 md:p-12 rounded-lg shadow-lg max-w-2xl mx-auto">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-green-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h1 className="text-4xl font-serif font-bold text-brand-primary mb-4">Thank You for Your Order!</h1>
        <p className="text-lg text-stone-600 mb-8">
          Your order has been placed successfully. You will receive an email confirmation shortly.
        </p>
        <Link 
          to="/products"
          className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-brand-dark transition duration-300"
        >
          Continue Shopping
        </Link>
      </div>
    </div>
  );
};

export default ConfirmationPage;
