
import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-[80vh] text-center">
      <div>
        <h1 className="text-6xl font-serif font-bold text-brand-secondary">404</h1>
        <h2 className="text-3xl font-bold text-brand-primary mt-4">Page Not Found</h2>
        <p className="text-stone-600 mt-2">Sorry, the page you are looking for does not exist.</p>
        <div className="mt-8">
          <Link 
            to="/" 
            className="bg-brand-primary text-white font-bold py-3 px-6 rounded-md hover:bg-brand-dark transition duration-300"
          >
            Go to Homepage
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;
