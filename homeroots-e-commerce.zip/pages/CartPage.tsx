
import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity } = useCart();

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  const shipping = 50; // Flat rate shipping
  const total = subtotal + shipping;

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-serif font-bold text-brand-primary mb-8 text-center">Your Shopping Cart</h1>
      {cartItems.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-xl text-stone-500 mb-4">Your cart is empty.</p>
          <Link to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-brand-dark transition duration-300">
            Continue Shopping
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
            {cartItems.map(item => (
              <div key={item.id} className="flex items-center justify-between py-4 border-b border-stone-200 last:border-b-0">
                <div className="flex items-center">
                  <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-md mr-4" />
                  <div>
                    <Link to={`/products/${item.id}`} className="font-bold text-lg text-brand-dark hover:text-brand-primary">{item.name}</Link>
                    <p className="text-stone-500">₹{item.price.toFixed(2)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-stone-300 rounded-md">
                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="px-3 py-1 font-bold">-</button>
                    <span className="px-3 py-1">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="px-3 py-1 font-bold">+</button>
                  </div>
                  <p className="font-bold w-24 text-right">₹{(item.price * item.quantity).toFixed(2)}</p>
                  <button onClick={() => removeFromCart(item.id)} className="text-stone-400 hover:text-red-500">&times;</button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md h-fit">
            <h2 className="text-2xl font-serif font-bold text-brand-primary mb-4">Order Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <p>Subtotal</p>
                <p>₹{subtotal.toFixed(2)}</p>
              </div>
              <div className="flex justify-between">
                <p>Shipping</p>
                <p>₹{shipping.toFixed(2)}</p>
              </div>
              <div className="flex justify-between font-bold text-lg border-t border-stone-200 pt-2 mt-2">
                <p>Total</p>
                <p>₹{total.toFixed(2)}</p>
              </div>
            </div>
            <Link to="/checkout">
              <button className="w-full mt-6 bg-brand-primary text-white font-bold py-3 rounded-md hover:bg-brand-dark transition duration-300">
                Proceed to Checkout
              </button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;
