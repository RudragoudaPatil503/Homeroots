
import React, { useState } from 'react';
import { products as initialProducts } from '../data';
import { Product } from '../types';

const AdminPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [isAdding, setIsAdding] = useState(false);
  const [newProduct, setNewProduct] = useState({
      name: '',
      category: 'Jaggery',
      price: '',
      quantityInStock: '',
      shortDescription: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewProduct(prev => ({ ...prev, [name]: value }));
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    // This is a mock implementation. In a real app, this would be an API call.
    const productToAdd: Product = {
      id: (products.length + 1).toString(),
      name: newProduct.name,
      category: newProduct.category as Product['category'],
      price: parseFloat(newProduct.price),
      quantityInStock: parseInt(newProduct.quantityInStock, 10),
      shortDescription: newProduct.shortDescription,
      longDescription: 'Default long description for new product.',
      image: `https://picsum.photos/seed/new${products.length + 1}/800/600`,
      rating: 0,
      reviews: []
    };
    setProducts(prev => [...prev, productToAdd]);
    setIsAdding(false);
    setNewProduct({ name: '', category: 'Jaggery', price: '', quantityInStock: '', shortDescription: '' });
  };
  
  const handleDeleteProduct = (id: string) => {
      setProducts(prev => prev.filter(p => p.id !== id));
  };

  return (
    <div className="container mx-auto p-8 bg-brand-light">
      <h1 className="text-3xl font-bold mb-6 text-brand-primary">Admin - Product Management</h1>
      
      <div className="mb-6">
          <button 
            onClick={() => setIsAdding(!isAdding)}
            className="bg-brand-accent text-white py-2 px-4 rounded-md hover:bg-green-700"
          >
              {isAdding ? 'Cancel' : 'Add New Product'}
          </button>
      </div>

      {isAdding && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h2 className="text-xl font-bold mb-4 text-brand-dark">New Product Form</h2>
              <form onSubmit={handleAddProduct} className="space-y-4">
                  <input name="name" value={newProduct.name} onChange={handleInputChange} placeholder="Product Name" className="w-full p-2 border rounded" required />
                  <textarea name="shortDescription" value={newProduct.shortDescription} onChange={handleInputChange} placeholder="Short Description" className="w-full p-2 border rounded" required />
                  <div className="grid grid-cols-3 gap-4">
                    <input name="price" type="number" value={newProduct.price} onChange={handleInputChange} placeholder="Price" className="w-full p-2 border rounded" required />
                    <input name="quantityInStock" type="number" value={newProduct.quantityInStock} onChange={handleInputChange} placeholder="Stock" className="w-full p-2 border rounded" required />
                    <select name="category" value={newProduct.category} onChange={handleInputChange} className="w-full p-2 border rounded">
                        <option>Jaggery</option>
                        <option>Honey</option>
                        <option>Pickles</option>
                        <option>Masala Powders</option>
                        <option>Oils</option>
                    </select>
                  </div>
                  <button type="submit" className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">Save Product</button>
              </form>
          </div>
      )}

      <div className="bg-white shadow-md rounded-lg overflow-x-auto">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Product Name</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Category</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Price</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Stock</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id}>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">{product.name}</td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">{product.category}</td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">₹{product.price.toFixed(2)}</td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">{product.quantityInStock}</td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm text-right">
                  <button className="text-blue-600 hover:text-blue-900 mr-4">Edit</button>
                  <button onClick={() => handleDeleteProduct(product.id)} className="text-red-600 hover:text-red-900">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminPage;
