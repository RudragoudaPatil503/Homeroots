
import React from 'react';
import { Link } from 'react-router-dom';
import Banner from '../components/Banner';
import ProductCard from '../components/ProductCard';
import { products } from '../data';
import { Product } from '../types';

const HomePage: React.FC = () => {
  const featuredProducts = products.slice(0, 4);
  const categories = [...new Set(products.map(p => p.category))];

  return (
    <div>
      <Banner />
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto">
                <h2 className="text-3xl font-bold font-serif text-brand-primary mb-4">Made in small batches.</h2>
                <p className="text-stone-600 text-lg">
                    We are not a big factory brand. We are a family-based authentic Malenadu kitchen. Each product is crafted with love and care, using traditional recipes and natural ingredients, ensuring the highest quality and taste.
                </p>
            </div>
        </div>
      </section>
      
      <section className="py-16 bg-brand-light">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center font-serif text-brand-primary mb-8">Featured Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product: Product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
           <div className="text-center mt-12">
                <Link to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-brand-dark transition duration-300">
                    View All Products
                </Link>
            </div>
        </div>
      </section>

       <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center font-serif text-brand-primary mb-8">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((category) => (
              <Link key={category} to={`/products?category=${category}`} className="block group text-center">
                 <div className="aspect-square bg-stone-200 rounded-lg flex items-center justify-center p-4 group-hover:bg-brand-secondary transition-colors duration-300">
                     <p className="font-semibold text-brand-dark group-hover:text-white">{category}</p>
                 </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
