
export interface Review {
  id: number;
  author: string;
  rating: number;
  comment: string;
}

export interface Product {
  id: string;
  name: string;
  image: string;
  shortDescription: string;
  longDescription: string;
  price: number;
  quantityInStock: number;
  category: 'Jaggery' | 'Honey' | 'Pickles' | 'Masala Powders' | 'Oils';
  rating: number;
  reviews: Review[];
}

export interface CartItem extends Product {
  quantity: number;
}
