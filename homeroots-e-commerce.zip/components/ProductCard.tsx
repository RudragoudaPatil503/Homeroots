
import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import StarRating from './StarRating';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 ease-in-out group">
      <Link to={`/products/${product.id}`} className="block">
        <div className="relative">
          <img src={product.image} alt={product.name} className="w-full h-56 object-cover" />
          <div className="absolute top-0 right-0 bg-brand-secondary text-white text-xs font-bold px-2 py-1 m-2 rounded-md">{product.category}</div>
        </div>
        <div className="p-4">
          <h3 className="text-lg font-semibold text-brand-dark mb-1 truncate">{product.name}</h3>
          <p className="text-stone-500 text-sm mb-2 h-10">{product.shortDescription}</p>
          <div className="flex justify-between items-center mt-4">
             <p className="text-lg font-bold text-brand-primary">₹{product.price.toFixed(2)}</p>
             <StarRating rating={product.rating} />
          </div>
        </div>
      </Link>
      <div className="p-4 pt-0">
          <button className="w-full bg-brand-primary text-white py-2 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out">
            View Details
          </button>
      </div>
    </div>
  );
};

export default ProductCard;
