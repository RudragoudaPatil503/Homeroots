
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-primary text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div>
            <h3 className="text-xl font-serif font-bold mb-4">HomeRoots</h3>
            <p className="text-stone-300">Authentic Malenadu homemade goodness, delivered from our home to yours.</p>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/#/products" className="text-stone-300 hover:text-white">Products</a></li>
              <li><a href="/#/cart" className="text-stone-300 hover:text-white">Your Cart</a></li>
              <li><a href="/#/admin" className="text-stone-300 hover:text-white">Admin</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-4">Contact Us</h3>
            <p className="text-stone-300">Malenadu, Karnataka</p>
            <p className="text-stone-300">Email: contact@homeroots.com</p>
          </div>
        </div>
        <div className="mt-8 border-t border-stone-600 pt-6 text-center text-sm text-stone-400">
          <p>&copy; {new Date().getFullYear()} HomeRoots. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
