
import React from 'react';
import { Link } from 'react-router-dom';

const Banner: React.FC = () => {
  return (
    <div className="relative bg-cover bg-center h-[60vh] text-white" style={{ backgroundImage: "url('https://picsum.photos/seed/nature/1600/900')" }}>
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center">
        <h1 className="text-4xl md:text-6xl font-serif font-bold leading-tight mb-4">
          Authentic Malenadu HomeMade Goodness
        </h1>
        <p className="text-lg md:text-2xl mb-8">Delivered From Our Home to Yours.</p>
        <Link 
          to="/products"
          className="bg-brand-secondary text-brand-primary font-bold py-3 px-8 rounded-full text-lg hover:bg-yellow-400 transition duration-300 ease-in-out"
        >
          Shop Now
        </Link>
      </div>
    </div>
  );
};

export default Banner;
