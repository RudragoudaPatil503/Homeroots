
import React, { useState, useEffect } from 'react';
import { useStore } from '../hooks/useStore';
import { Product, ProductCategory } from '../types';

const emptyProduct: Omit<Product, 'id'|'rating'|'reviews'> = {
    name: '',
    image: '',
    shortDescription: '',
    longDescription: '',
    price: 0,
    stock: 0,
    category: ProductCategory.JAGGERY,
};

const AdminPage: React.FC = () => {
    const { products, addProduct, updateProduct, deleteProduct } = useStore();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | Omit<Product, 'id'|'rating'|'reviews'> | null>(null);

    const openModal = (product: Product | null = null) => {
        setEditingProduct(product || emptyProduct);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingProduct(null);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        if (!editingProduct) return;
        setEditingProduct({ ...editingProduct, [name]: name === 'price' || name === 'stock' ? Number(value) : value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingProduct) return;

        if ('id' in editingProduct) {
            updateProduct(editingProduct);
        } else {
            addProduct(editingProduct);
        }
        closeModal();
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-serif text-brand-primary">Manage Products</h1>
                <button onClick={() => openModal()} className="bg-brand-secondary text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                    Add New Product
                </button>
            </div>

            <div className="bg-white shadow-lg rounded-lg overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-4 font-semibold">Name</th>
                            <th className="p-4 font-semibold">Category</th>
                            <th className="p-4 font-semibold">Price</th>
                            <th className="p-4 font-semibold">Stock</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y">
                        {products.map(product => (
                            <tr key={product.id}>
                                <td className="p-4">{product.name}</td>
                                <td className="p-4">{product.category}</td>
                                <td className="p-4">₹{product.price}</td>
                                <td className="p-4">{product.stock}</td>
                                <td className="p-4 flex space-x-2">
                                    <button onClick={() => openModal(product)} className="text-blue-600 hover:underline">Edit</button>
                                    <button onClick={() => deleteProduct(product.id)} className="text-red-600 hover:underline">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isModalOpen && editingProduct && (
                <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 w-full max-w-lg max-h-full overflow-y-auto">
                        <h2 className="text-2xl font-semibold mb-4">{'id' in editingProduct ? 'Edit Product' : 'Add Product'}</h2>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <input name="name" value={editingProduct.name} onChange={handleInputChange} placeholder="Product Name" className="w-full border-gray-300 rounded-md" required/>
                            <input name="image" value={editingProduct.image} onChange={handleInputChange} placeholder="Image URL (e.g. https://picsum.photos/...)" className="w-full border-gray-300 rounded-md" required/>
                            <textarea name="shortDescription" value={editingProduct.shortDescription} onChange={handleInputChange} placeholder="Short Description" className="w-full border-gray-300 rounded-md" required/>
                            <textarea name="longDescription" value={editingProduct.longDescription} onChange={handleInputChange} placeholder="Long Description" rows={4} className="w-full border-gray-300 rounded-md" required/>
                            <div className="grid grid-cols-2 gap-4">
                                <input type="number" name="price" value={editingProduct.price} onChange={handleInputChange} placeholder="Price" className="w-full border-gray-300 rounded-md" required/>
                                <input type="number" name="stock" value={editingProduct.stock} onChange={handleInputChange} placeholder="Stock" className="w-full border-gray-300 rounded-md" required/>
                            </div>
                            <select name="category" value={editingProduct.category} onChange={handleInputChange} className="w-full border-gray-300 rounded-md">
                                {Object.values(ProductCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                            <div className="flex justify-end space-x-4">
                                <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200 rounded-md">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminPage;
