
import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../hooks/useStore';
import ProductCard from '../components/ProductCard';
import { ProductCategory } from '../types';

const HomePage: React.FC = () => {
  const { products } = useStore();
  const featuredProducts = products.slice(0, 4);
  const categories = Object.values(ProductCategory);

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center rounded-lg overflow-hidden h-96 flex items-center justify-center text-center text-white" 
        style={{ backgroundImage: `url('https://picsum.photos/seed/malenadu/1600/800')` }}
      >
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="relative z-10 p-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold tracking-tight">
            Authentic Malenadu HomeMade Goodness
          </h1>
          <p className="mt-4 text-xl md:text-2xl font-light">Delivered to You.</p>
          <Link
            to="/products"
            className="mt-8 inline-block bg-brand-accent text-brand-primary font-bold py-3 px-8 rounded-lg hover:bg-yellow-400 transition-colors duration-300"
          >
            Shop Now
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section className="text-center max-w-3xl mx-auto">
        <h2 className="text-3xl font-serif text-brand-primary mb-4">From Our Home to Yours</h2>
        <p className="text-lg text-gray-700 leading-relaxed">
          HomeRoots is born from a love for traditional Malenadu recipes passed down through generations. We use only the finest natural ingredients, prepared in small batches with care, ensuring every product is pure, authentic, and full of flavor. No preservatives, no chemicals—just pure, homemade goodness.
        </p>
      </section>

      {/* Featured Products Section */}
      <section>
        <h2 className="text-3xl font-serif text-brand-primary text-center mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
      
      {/* Categories Section */}
      <section>
        <h2 className="text-3xl font-serif text-brand-primary text-center mb-8">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.map(category => (
            <Link 
              key={category} 
              to={`/products?category=${encodeURIComponent(category)}`}
              className="block p-6 bg-white rounded-lg shadow-sm text-center hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <span className="font-semibold text-brand-primary">{category}</span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
