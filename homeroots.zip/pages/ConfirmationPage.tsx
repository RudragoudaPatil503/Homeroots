
import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useStore } from '../hooks/useStore';

const ConfirmationPage: React.FC = () => {
    const [searchParams] = useSearchParams();
    const orderId = searchParams.get('orderId');
    const { orders } = useStore();
    const order = orders.find(o => o.id === orderId);

    if (!order) {
        return (
            <div className="text-center py-20 bg-white rounded-lg shadow-lg">
                <h1 className="text-2xl font-bold text-red-600 mb-4">Order Not Found</h1>
                <p className="text-gray-600">We couldn't find the details for this order. Please check your order history.</p>
                <Link to="/" className="mt-8 inline-block bg-brand-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-brand-text transition-colors duration-300">
                    Go to Homepage
                </Link>
            </div>
        );
    }
    
    return (
        <div className="text-center py-12 px-6 bg-white rounded-lg shadow-lg max-w-2xl mx-auto">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-brand-secondary mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h1 className="text-3xl font-serif text-brand-primary mb-2">Thank you for your order!</h1>
            <p className="text-gray-600 mb-6">Your order has been placed successfully. A confirmation has been sent to your email.</p>
            
            <div className="text-left bg-gray-50 p-6 rounded-lg border border-gray-200 mb-8">
                <h2 className="text-lg font-semibold mb-3">Order Summary</h2>
                <p><strong>Order ID:</strong> {order.id}</p>
                <p><strong>Date:</strong> {order.date.toLocaleDateString()}</p>
                <p><strong>Total:</strong> ₹{order.total}</p>
                <p className="mt-2"><strong>Shipping to:</strong></p>
                <address className="not-italic text-gray-700">
                    {order.shippingAddress.name}<br />
                    {order.shippingAddress.address}<br />
                    {order.shippingAddress.city}, {order.shippingAddress.zip}
                </address>
            </div>
            
            <Link to="/products" className="inline-block bg-brand-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-brand-text transition-colors duration-300">
                Continue Shopping
            </Link>
        </div>
    );
};

export default ConfirmationPage;
