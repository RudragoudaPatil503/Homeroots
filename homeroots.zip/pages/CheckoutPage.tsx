
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../hooks/useStore';

const CheckoutPage: React.FC = () => {
    const { cart, cartTotal, placeOrder } = useStore();
    const navigate = useNavigate();
    const [shippingInfo, setShippingInfo] = useState({ name: '', address: '', city: '', zip: '' });

    if (cart.length === 0) {
        navigate('/products');
        return null;
    }

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setShippingInfo(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const order = placeOrder({
            items: cart,
            total: cartTotal,
            shippingAddress: shippingInfo,
        });
        navigate(`/confirmation?orderId=${order.id}`);
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            <div className="lg:col-span-3">
                <h1 className="text-3xl font-serif text-brand-primary mb-6">Checkout</h1>
                <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg space-y-6">
                    <div>
                        <h2 className="text-xl font-semibold text-brand-text mb-4">Shipping Information</h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                                <input type="text" name="name" id="name" required value={shippingInfo.name} onChange={handleInputChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                            </div>
                            <div>
                                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                                <input type="text" name="address" id="address" required value={shippingInfo.address} onChange={handleInputChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                            </div>
                            <div>
                                <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
                                <input type="text" name="city" id="city" required value={shippingInfo.city} onChange={handleInputChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                            </div>
                            <div>
                                <label htmlFor="zip" className="block text-sm font-medium text-gray-700">ZIP / Postal Code</label>
                                <input type="text" name="zip" id="zip" required value={shippingInfo.zip} onChange={handleInputChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary" />
                            </div>
                        </div>
                    </div>
                    <div>
                         <h2 className="text-xl font-semibold text-brand-text mb-4">Payment Details (Razorpay Mock)</h2>
                         <p className="text-sm text-gray-500 mb-4">This is a mock payment form. Do not enter real credit card details.</p>
                         <div className="space-y-4">
                            <input type="text" placeholder="Card Number" className="block w-full border-gray-300 rounded-md shadow-sm" />
                            <div className="grid grid-cols-2 gap-4">
                                <input type="text" placeholder="MM/YY" className="block w-full border-gray-300 rounded-md shadow-sm" />
                                <input type="text" placeholder="CVC" className="block w-full border-gray-300 rounded-md shadow-sm" />
                            </div>
                         </div>
                    </div>
                    <button type="submit" className="w-full bg-brand-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-text transition-colors duration-300">
                        Place Order (₹{cartTotal})
                    </button>
                </form>
            </div>
            <div className="lg:col-span-2">
                <div className="bg-white p-6 rounded-lg shadow-lg sticky top-24">
                    <h2 className="text-xl font-semibold mb-4">Your Order</h2>
                    <ul className="divide-y divide-gray-200">
                        {cart.map(item => (
                            <li key={item.id} className="py-3 flex justify-between items-center">
                                <div className="flex items-center space-x-3">
                                    <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded"/>
                                    <div>
                                        <p className="font-semibold">{item.name}</p>
                                        <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                                    </div>
                                </div>
                                <p>₹{item.price * item.quantity}</p>
                            </li>
                        ))}
                    </ul>
                    <div className="border-t pt-4 mt-4 flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span>₹{cartTotal}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;
