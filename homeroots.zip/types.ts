
export enum ProductCategory {
  JAGGERY = "Jaggery",
  HONEY = "Honey",
  PICKLES = "Pickles",
  MASALA = "Masala Powders",
  OILS = "Cold Pressed Oils",
}

export interface Review {
  id: number;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  image: string;
  shortDescription: string;
  longDescription: string;
  price: number;
  stock: number;
  category: ProductCategory;
  rating: number;
  reviews: Review[];
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  name: string;
  email: string;
}

export interface Order {
    id: string;
    items: CartItem[];
    total: number;
    shippingAddress: {
        name: string;
        address: string;
        city: string;
        zip: string;
    };
    date: Date;
}
