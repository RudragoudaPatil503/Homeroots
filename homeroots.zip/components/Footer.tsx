
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-primary text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="font-serif text-xl italic mb-4">"Made in small batches. From our home to your home."</p>
          <p className="text-sm">&copy; {new Date().getFullYear()} HomeRoots. All Rights Reserved.</p>
          <p className="text-xs mt-2 opacity-70">Authentic Malenadu Goodness, Crafted with Love.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
