
import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import Rating from './Rating';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 bg-white group">
      <Link to={`/products/${product.id}`}>
        <div className="overflow-hidden">
             <img src={product.image} alt={product.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
        <div className="p-4">
          <h3 className="text-lg font-semibold font-serif text-brand-primary truncate">{product.name}</h3>
          <p className="text-sm text-gray-600 mt-1 h-10">{product.shortDescription}</p>
          <div className="flex justify-between items-center mt-4">
            <p className="text-xl font-bold text-brand-text">₹{product.price}</p>
            <Rating rating={product.rating} />
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
