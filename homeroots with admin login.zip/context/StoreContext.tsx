import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Product, CartItem, User, Order } from '../types';
import { MOCK_PRODUCTS } from '../data/products';

interface StoreContextType {
  products: Product[];
  cart: CartItem[];
  user: User | null;
  orders: Order[];
  wishlist: string[];
  addProduct: (product: Omit<Product, 'id' | 'rating' | 'reviews'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addToCart: (product: Product, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  login: (user: User) => void;
  logout: () => void;
  placeOrder: (order: Omit<Order, 'id' | 'date'>) => Order;
  addToWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
}

export const StoreContext = createContext<StoreContextType | undefined>(undefined);

interface StoreProviderProps {
  children: ReactNode;
}

export const StoreProvider: React.FC<StoreProviderProps> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const item = window.localStorage.getItem('homeRootsCart');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error(error);
      return [];
    }
  });
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const item = window.localStorage.getItem('homeRootsWishlist');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error(error);
      return [];
    }
  });


  useEffect(() => {
    try {
      window.localStorage.setItem('homeRootsCart', JSON.stringify(cart));
    } catch (error) {
      console.error(error);
    }
  }, [cart]);

  useEffect(() => {
    try {
      window.localStorage.setItem('homeRootsWishlist', JSON.stringify(wishlist));
    } catch (error) {
      console.error(error);
    }
  }, [wishlist]);

  const addToCart = useCallback((product: Product, quantity: number) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  }, []);

  const updateCartQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(prevCart =>
        prevCart.map(item =>
          item.id === productId ? { ...item, quantity } : item
        )
      );
    }
  }, [removeFromCart]);
  
  const clearCart = useCallback(() => {
      setCart([]);
  }, []);

  const login = (user: User) => setUser(user);
  const logout = () => setUser(null);

  const addProduct = (newProductData: Omit<Product, 'id' | 'rating' | 'reviews'>) => {
    const newProduct: Product = {
      ...newProductData,
      id: `prod_${Date.now()}`,
      rating: 0,
      reviews: [],
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const deleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const placeOrder = (orderData: Omit<Order, 'id'|'date'>): Order => {
    const newOrder: Order = {
        ...orderData,
        id: `order_${Date.now()}`,
        date: new Date(),
    };
    setOrders(prev => [...prev, newOrder]);
    clearCart();
    return newOrder;
  };

  const addToWishlist = useCallback((productId: string) => {
    setWishlist(prev => [...new Set([...prev, productId])]);
  }, []);

  const removeFromWishlist = useCallback((productId: string) => {
    setWishlist(prev => prev.filter(id => id !== productId));
  }, []);

  const isInWishlist = useCallback((productId: string): boolean => {
    return wishlist.includes(productId);
  }, [wishlist]);

  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);
  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  const wishlistCount = wishlist.length;

  const value = {
    products,
    cart,
    user,
    orders,
    wishlist,
    addProduct,
    updateProduct,
    deleteProduct,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    login,
    logout,
    placeOrder,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    cartCount,
    cartTotal,
    wishlistCount,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
};
