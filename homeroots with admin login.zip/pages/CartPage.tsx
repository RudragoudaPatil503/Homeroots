
import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../hooks/useStore';

const CartPage: React.FC = () => {
  const { cart, cartTotal, updateCartQuantity, removeFromCart } = useStore();

  return (
    <div>
      <h1 className="text-3xl font-serif text-brand-primary mb-6">Your Shopping Cart</h1>
      {cart.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg shadow-md">
          <p className="text-xl text-gray-600 mb-4">Your cart is empty.</p>
          <Link
            to="/products"
            className="inline-block bg-brand-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-brand-text transition-colors duration-300"
          >
            Continue Shopping
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
            <ul className="divide-y divide-gray-200">
              {cart.map(item => (
                <li key={item.id} className="py-4 flex items-center space-x-4">
                  <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md" />
                  <div className="flex-grow">
                    <Link to={`/products/${item.id}`} className="font-semibold text-brand-primary hover:underline">{item.name}</Link>
                    <p className="text-sm text-gray-500">₹{item.price}</p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <input
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={e => updateCartQuantity(item.id, parseInt(e.target.value, 10))}
                      className="w-16 border-gray-300 rounded-lg shadow-sm focus:ring-brand-primary focus:border-brand-primary"
                    />
                    <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:text-red-700">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </div>
                  <p className="font-semibold w-20 text-right">₹{item.price * item.quantity}</p>
                </li>
              ))}
            </ul>
          </div>
          <aside className="bg-white p-6 rounded-lg shadow-md h-fit">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{cartTotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>FREE</span>
              </div>
              <div className="border-t pt-2 mt-2 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>₹{cartTotal}</span>
              </div>
            </div>
            <Link
              to="/checkout"
              className="mt-6 w-full text-center block bg-brand-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-text transition-colors duration-300"
            >
              Proceed to Checkout
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
};

export default CartPage;
