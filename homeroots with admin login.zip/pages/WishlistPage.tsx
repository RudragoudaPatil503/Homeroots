import React from 'react';
import { useStore } from '../hooks/useStore';
import { Link, useNavigate } from 'react-router-dom';
import { Product } from '../types';

const WishlistPage: React.FC = () => {
    const { products, wishlist, removeFromWishlist, addToCart } = useStore();
    const navigate = useNavigate();
    const wishlistItems: Product[] = products.filter(p => wishlist.includes(p.id));

    const handleAddToCart = (item: Product) => {
        addToCart(item, 1);
        removeFromWishlist(item.id);
        navigate('/cart');
    };

    return (
        <div>
            <h1 className="text-3xl font-serif text-brand-primary mb-6">Your Wishlist</h1>
            {wishlistItems.length === 0 ? (
                <div className="text-center py-16 bg-white rounded-lg shadow-md">
                    <p className="text-xl text-gray-600 mb-4">Your wishlist is empty.</p>
                    <p className="text-gray-500 mb-8">Add your favorite items to your wishlist to keep track of them.</p>
                    <Link
                        to="/products"
                        className="inline-block bg-brand-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-brand-text transition-colors duration-300"
                    >
                        Discover Products
                    </Link>
                </div>
            ) : (
                <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                    <ul className="divide-y divide-gray-200">
                        {wishlistItems.map(item => (
                            <li key={item.id} className="py-4 flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
                                <img src={item.image} alt={item.name} className="w-32 h-32 object-cover rounded-md" />
                                <div className="flex-grow text-center sm:text-left">
                                    <Link to={`/products/${item.id}`} className="font-semibold text-lg text-brand-primary hover:underline">{item.name}</Link>
                                    <p className="text-xl font-bold text-brand-text mt-1">₹{item.price}</p>
                                </div>
                                <div className="flex items-center space-x-3 flex-shrink-0">
                                    <button onClick={() => handleAddToCart(item)} disabled={item.stock === 0} className="px-4 py-2 bg-brand-secondary text-white font-semibold rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
                                        Add to Cart
                                    </button>
                                    <button onClick={() => removeFromWishlist(item.id)} className="text-red-500 hover:text-red-700" aria-label="Remove from wishlist">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default WishlistPage;
