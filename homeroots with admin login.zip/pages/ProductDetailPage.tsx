import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../hooks/useStore';
import Rating from '../components/Rating';

const HeartIcon: React.FC<{ filled: boolean }> = ({ filled }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${filled ? 'text-red-500' : 'text-gray-600'}`} fill={filled ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
    </svg>
);

const ProductDetailPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const { products, addToCart, isInWishlist, addToWishlist, removeFromWishlist } = useStore();
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');

  const product = products.find(p => p.id === productId);

  if (!product) {
    return <div className="text-center py-20"><h2>Product not found</h2></div>;
  }
  
  const isWished = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    navigate('/cart');
  };

  const handleWishlistToggle = () => {
    if (isWished) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product.id);
    }
  };
  
  const renderStockStatus = () => {
    if (product.stock === 0) {
      return <p className="text-red-600 font-semibold text-lg mb-4">Out of Stock</p>;
    }
    if (product.stock > 0 && product.stock <= 10) {
      return <p className="text-yellow-600 font-semibold text-lg mb-4">Low Stock (Only {product.stock} left!)</p>;
    }
    return <p className="text-brand-secondary font-semibold text-lg mb-4">In Stock</p>;
  };


  return (
    <div className="bg-white p-4 sm:p-8 rounded-lg shadow-lg">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        {/* Product Image */}
        <div>
          <img src={product.image} alt={product.name} className="w-full h-auto object-cover rounded-lg shadow-md" />
        </div>

        {/* Product Details */}
        <div className="flex flex-col">
          <h1 className="text-3xl lg:text-4xl font-serif font-bold text-brand-primary">{product.name}</h1>
          <div className="flex items-center gap-4 my-4">
            <Rating rating={product.rating} />
            <span className="text-gray-600">{product.reviews.length} reviews</span>
          </div>
          <p className="text-lg text-gray-700 mb-4">{product.shortDescription}</p>
          <p className="text-3xl font-bold text-brand-text mb-2">₹{product.price}</p>
          {renderStockStatus()}
          
          <div className="flex items-center gap-4 mb-6">
            <label htmlFor="quantity" className="font-semibold">Quantity:</label>
            <input
              type="number"
              id="quantity"
              min="1"
              max={product.stock}
              value={quantity}
              onChange={e => setQuantity(Math.max(1, parseInt(e.target.value, 10)))}
              className="w-20 border-gray-300 rounded-lg shadow-sm focus:ring-brand-primary focus:border-brand-primary"
              disabled={product.stock === 0}
            />
          </div>
          
          <div className="flex items-stretch gap-4">
            <button
              onClick={handleAddToCart}
              className="flex-grow bg-brand-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-text transition-colors duration-300 disabled:bg-gray-400"
              disabled={product.stock === 0}
            >
              {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
            </button>
            <button
                onClick={handleWishlistToggle}
                className="p-3 border rounded-lg hover:bg-gray-100 transition-colors"
                aria-label={isWished ? 'Remove from wishlist' : 'Add to wishlist'}
            >
                <HeartIcon filled={isWished} />
            </button>
          </div>
        </div>
      </div>

      {/* Description and Reviews Tabs */}
      <div className="mt-12">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('description')}
              className={`${activeTab === 'description' ? 'border-brand-primary text-brand-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              Description
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`${activeTab === 'reviews' ? 'border-brand-primary text-brand-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              Reviews ({product.reviews.length})
            </button>
          </nav>
        </div>
        <div className="py-6">
          {activeTab === 'description' && (
            <p className="text-gray-700 leading-relaxed">{product.longDescription}</p>
          )}
          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {product.reviews.length > 0 ? (
                product.reviews.map(review => (
                  <div key={review.id} className="border-b pb-4">
                    <div className="flex items-center mb-2">
                        <Rating rating={review.rating} />
                        <p className="ml-4 font-bold text-brand-text">{review.author}</p>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">{review.date}</p>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))
              ) : (
                <p>No reviews yet.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
