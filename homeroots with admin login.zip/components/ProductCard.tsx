import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import Rating from './Rating';
import { useStore } from '../hooks/useStore';

interface ProductCardProps {
  product: Product;
}

const HeartIcon: React.FC<{ filled: boolean }> = ({ filled }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${filled ? 'text-red-500' : 'text-brand-primary'}`} fill={filled ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
    </svg>
);


const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useStore();
  const isWished = isInWishlist(product.id);

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isWished) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product.id);
    }
  };

  const getStockStatusBadge = () => {
    if (product.stock === 0) {
      return <span className="absolute top-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">Out of Stock</span>;
    }
    if (product.stock > 0 && product.stock <= 10) {
      return <span className="absolute top-2 left-2 bg-yellow-500 text-white text-xs font-bold px-2 py-1 rounded">Low Stock</span>;
    }
    return null;
  };
  
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 bg-white group">
      <Link to={`/products/${product.id}`} className="block">
        <div className="overflow-hidden relative">
             <img src={product.image} alt={product.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
             {getStockStatusBadge()}
              <button
                onClick={handleWishlistToggle}
                className="absolute top-2 right-2 p-2 rounded-full bg-white/80 hover:bg-white transition-opacity opacity-0 group-hover:opacity-100"
                aria-label={isWished ? 'Remove from wishlist' : 'Add to wishlist'}
             >
                <HeartIcon filled={isWished} />
             </button>
        </div>
        <div className="p-4">
          <h3 className="text-lg font-semibold font-serif text-brand-primary truncate">{product.name}</h3>
          <p className="text-sm text-gray-600 mt-1 h-10">{product.shortDescription}</p>
          <div className="flex justify-between items-center mt-4">
            <p className="text-xl font-bold text-brand-text">₹{product.price}</p>
            <Rating rating={product.rating} />
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
