import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useStore } from '../hooks/useStore';
import { useNavigate } from 'react-router-dom';

const AdminSidebar: React.FC = () => {
  const { logout } = useStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const linkClasses = "flex items-center px-4 py-2 text-gray-700 rounded-lg";
  const activeLinkClasses = "bg-brand-primary text-white";

  return (
    <aside className="w-64 bg-white shadow-md flex-shrink-0 flex flex-col">
      <div className="p-4 border-b">
        <Link to="/" className="text-2xl font-serif font-bold text-brand-primary">
          HomeRoots Admin
        </Link>
      </div>
      <nav className="flex-grow p-4 space-y-2">
        <NavLink
          to="/admin"
          end
          className={({ isActive }) => `${linkClasses} ${isActive ? activeLinkClasses : 'hover:bg-gray-200'}`}
        >
          Products
        </NavLink>
        {/* Add more admin links here as needed */}
      </nav>
      <div className="p-4 border-t">
        <Link to="/" className="text-sm text-brand-primary hover:underline mb-4 block">
          &larr; Back to Store
        </Link>
        <button onClick={handleLogout} className="w-full px-4 py-2 text-sm text-left text-red-600 hover:bg-red-50 rounded-lg">
          Logout
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;
